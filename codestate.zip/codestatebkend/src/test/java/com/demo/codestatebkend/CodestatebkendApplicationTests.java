package com.demo.codestatebkend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodestatebkendApplicationTests {

    @Test
    void contextLoads() {
    }

}
